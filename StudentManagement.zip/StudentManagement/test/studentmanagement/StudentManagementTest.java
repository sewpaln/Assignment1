/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package studentmanagement;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author nishka
 */
public class StudentManagementTest {
private StudentManagement studentManagement;  

    public StudentManagementTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
 studentManagement = new StudentManagement();
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class StudentManagement.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        StudentManagement.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    @Test 
    public void testSaveStudent(){
    //create a test student
    Student student = new Student(1, "Mayur", 21, "mayur@example.com", "computer science");
     assertTrue(studentManagement.saveStudent(student));
    // Add assertions to check if the student was saved correctly in memory
    }
    @Test
    public void TestSearchStudent() {
        Student expectedStudent = new Student(1, "Mayur", 21, "mayur@example.com", "computer science");
        Student foundStudent = studentManagement.searchStudent("1");
        assertEquals(expectedStudent, foundStudent);
    }
    
     @Test
    public void TestSearchStudent_StudentNotFound() {
        Student foundStudent = studentManagement.searchStudent("nonexistent_id");
        assertNull(foundStudent);
    }

    @Test
    public void TestDeleteStudent() {
        assertTrue(studentManagement.deleteStudent("1"));
        // check if the student was successfully deleted
    }

    @Test
    public void TestDeleteStudent_StudentNotFound() {
        assertFalse(studentManagement.deleteStudent("nonexistent_id"));
    }

    @Test
    public void TestStudentAge_StudentAgeValid() {
        assertTrue(studentManagement.studentAgeIsValid(18)); // 18 is a valid age
    }

    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        assertFalse(studentManagement.studentAgeIsValid(15)); // 15 is an invalid age
    }

    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        assertFalse(studentManagement.studentAgeIsValid("invalid_age")); // "invalid_age" is not a valid age
    }
    
    }

