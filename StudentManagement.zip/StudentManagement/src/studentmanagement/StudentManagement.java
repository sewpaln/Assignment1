/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagement;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author nishka
 */
public class StudentManagement {
    private static ArrayList<Student> studentList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    

    /**
     * @param args the command lin1111e arguments
     */
    public static void main(String[] args) {
     while (true) {
            displayMainMenu();
            int choice = getUserChoice();

            switch (choice) {
                case 1:
                    captureNewStudent();
                    break;
                case 2:
                    searchStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    printStudentReport();
                    break;
                case 5:
                    exitApplication();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // display the main menu
    private static void displayMainMenu() {
        System.out.println("\n STUDENT MANAGEMENT APPLICATION");
        System.out.println("*************************************************");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student.");
        System.out.println("(2) Search for a student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit Application.");
    }
    
    
    // request the user's menu choices
    private static int getUserChoice() {
        System.out.print("Enter your choice: ");
        return scanner.nextInt();
    }

    // record a new student's information
    private static void captureNewStudent() {
        System.out.println("\nCAPTURE A NEW STUDENT");
        System.out.println("**********************************");

        System.out.print("Enter the student id: ");
        int id = scanner.nextInt();
        scanner.nextLine(); //capture the data on a new line

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age;
        do {
            System.out.print("Enter the student age: ");
            age = scanner.nextInt();
            if (age < 16) {
                System.out.println("You have entered an incorrect student age!!! Please re-enter the student age.");
            }
        } while (age < 16); //set an age restriction

        scanner.nextLine(); // capture the data on a new line

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        Student student = new Student(id, name, age, email, course);
        studentList.add(student);

        System.out.println("Student details have been successfully saved.");
    }

    // search for a student by their ID
    private static void searchStudent() {
        System.out.print("\nEnter the student id to search: ");
        int searchId = scanner.nextInt();

        for (Student student : studentList) {
            if (student.getId() == searchId) {
                student.displayStudentDetails();
                return;
            }
        }

        System.out.println("Student with Student Id: " + searchId + " was not found!");
    }
       
    // delete a student by their ID
    private static void deleteStudent() {
        System.out.print("\n Enter the student ID to be deleted: ");
        int deleteId = scanner.nextInt();

        for (int i = 0; i < studentList.size(); i++) {
            if (studentList.get(i).getId() == deleteId) {
                System.out.print("Are you sure? Press (Y) to confirm: ");
                scanner.nextLine(); 
                String confirm = scanner.nextLine();
                if (confirm.equalsIgnoreCase("Y")) {
                    studentList.remove(i);
                    System.out.println("Student with Student Id: " + deleteId + " was deleted!");
                    return;
                }
            }
        }
          System.out.println("Student with Student Id: " + deleteId + " was not found!");
    }

    // print a report of all students
    private static void printStudentReport() {
        System.out.println("\nSTUDENT REPORT");
        for (int i = 0; i < studentList.size(); i++) {
            System.out.println("STUDENT " + (i + 1));
            studentList.get(i).displayStudentDetails();
        }
    }

    // to exit the application
    private static void exitApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }
}
    


