/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarysystem;

/**
 *
 * @author nishka
 */
public class library {
  private book[] books;
  private int bookCount;

    public library(int capacity) {
        books = new book[capacity];
        bookCount = 0;
    }
     public void addbook(book book) {
        if (bookCount < books.length) {
            books[bookCount] = book;
            bookCount++;
            System.out.println("Book added to the library.");
        } else {
            System.out.println("Library is full. Cannot add more books.");
        }
    }

    public void listbooks() {
        System.out.println("Library Catalog:");
        for (int i = 0; i < bookCount; i++) {
            System.out.println("Title: " + books[i].getTitle());
            System.out.println("Author: " + books[i].getAuthor());
            System.out.println("Year: " + books[i].getYear());
            System.out.println("Checked Out: " + (books[i].isIsCheckedOut() ? "Yes" : "No"));
            System.out.println("--------");
        }
    }
}
