/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package librarysystem;

import java.util.Scanner;

/**
 *
 * @author nishk
 */
public class LibrarySystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Scanner scanner = new Scanner(System.in);
    System.out.println("Welcome to the libray system.");
        
        // Create a library with a capacity of 10 books
        library library = new library(10);

        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1. Add a book");
            System.out.println("2. List all books");
            System.out.println("3. Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter book title:");
                    String title = scanner.next();
                    System.out.println("Enter author:");
                    String author = scanner.next();
                    System.out.println("Enter publication year:");
                    int year = scanner.nextInt();
                    book newBook = new book(title, author, year);
                    library.addbook(newBook);
                    break;
                case 2:
                    library.listbooks();
                    break;
                case 3:
                    System.out.println("Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please select again.");
            }
        }
    }
}
