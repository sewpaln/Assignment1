/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarysystem;
import java.util.Scanner;
/**
 *
 * @author nishka
 */
public class book {
    private String title;
    private String author;
    private int year;
    private boolean isCheckedOut; 
 
  
    public book(String title, String author, int year) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.isCheckedOut = false;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getYear() {
        return year;
    }

    public boolean isIsCheckedOut() {
        return isCheckedOut;
    }
    
    public void checkOut() {
        isCheckedOut = true;
    }

    public void returnBook() {
        isCheckedOut = false;
    }
    
 
     
}
