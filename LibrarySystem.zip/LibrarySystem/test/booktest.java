/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


import librarysystem.book;
import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author nishka
 */
public class booktest {
 private book book;
    
    
    @BeforeEach
    public void setUp() {
    book = new book("Sample Title", "Sample Author", 2005);
    }
  
    @Test
    public void testGetTitle() {
        assertEquals("Sample Title", book.getTitle());
    }

    @Test
    public void testGetAuthor() {
        assertEquals("Sample Author", book.getAuthor());  
  
    }
    
    @Test
    public void testGetYear() {
        assertEquals(2023, book.getYear());
    }

    @Test
    public void testIsCheckedOutInitiallyFalse() {
        assertFalse(book.isIsCheckedOut());
    }

    @Test
    public void testCheckOut() {
        book.checkOut();
        assertTrue(book.isIsCheckedOut());
    }

    @Test
    public void testReturnBook() {
        book.checkOut();
        book.returnBook();
        assertFalse(book.isIsCheckedOut());
    }

    
}
